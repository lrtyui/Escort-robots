<template>
	<view class="container">
		<!-- 自定义顶部导航栏 -->
		<view class="custom-navbar">
			<view class="navbar-left">
				<image src="/static/user-icon.png" class="user-icon"></image>
			</view>
			<view class="navbar-title">老年陪护助手</view>
		</view>
		<view class="header">
			<text class="subtitle">为您提供全天候的健康关怀</text>
		</view>
		
		<!-- 紧急呼叫按钮 -->
		<uni-fab 
			:pattern="fabPattern"
			:content="fabContent"
			horizontal="right" 
			vertical="bottom"
			direction="vertical"
			@trigger="handleEmergency">
		</uni-fab>
		
		<!-- 健康数据概览 - 使用uni-ui的统计卡片组件 -->
		<uni-card title="今日健康数据" is-shadow>
			<uni-row :gutter="16">
				<uni-col :span="12">
					<uni-statistic 
						title="心率" 
						value="78" 
						suffix="次/分"
						:value-style="valueStyle"
						:title-style="titleStyle">
					</uni-statistic>
				</uni-col>
				<uni-col :span="12">
					<uni-statistic 
						title="血压" 
						value="120/80" 
						suffix="mmHg"
						:value-style="valueStyle"
						:title-style="titleStyle">
					</uni-statistic>
				</uni-col>
			</uni-row>
			<view style="margin-top: 15px;">
				<uni-button 
					@click="toggleChart"
					type="default" 
					size="mini"
					plain>
					{{ showChart ? '隐藏' : '查看' }}健康趋势
				</uni-button>
			</view>
			<view v-if="showChart" style="margin-top: 20px;">
				<canvas 
					id="healthChart" 
					style="width: 100%; height: 300px;"
					canvas-id="healthChart">
				</canvas>
			</view>
		</uni-card>
		
		<!-- 功能入口 - 优化对齐布局 -->
		<uni-section title="快捷功能" type="line"></uni-section>
		<uni-grid :column="3" :highlight="true" @change="change" :square="true">
			<uni-grid-item>
				<view class="grid-item">
					<uni-icons type="notification-filled" size="30" color="#3498db"></uni-icons>
					<text>用药提醒</text>
					<uni-badge :text="medicationCount" type="error" size="small" absolute="rightTop"></uni-badge>
				</view>
			</uni-grid-item>
			<uni-grid-item>
				<view class="grid-item">
					<uni-icons type="calendar-filled" size="30" color="#4CAF50"></uni-icons>
					<text>服务预约</text>
				</view>
			</uni-grid-item>
			<uni-grid-item>
				<view class="grid-item">
					<uni-icons type="phone-filled" size="30" color="#FF9800"></uni-icons>
					<text>联系护工</text>
				</view>
			</uni-grid-item>
		</uni-grid>
		
		<!-- 用药提醒列表 -->
		<uni-card title="今日用药提醒" v-if="showMedication">
			<uni-list>
				<uni-list-item 
					v-for="(item, index) in medications" 
					:key="index"
					:title="item.name" 
					:note="`${item.time} | ${item.dosage}`"
					:rightText="item.status"
					:thumb="item.thumb"
					clickable
					@click="takeMedication(index)">
				</uni-list-item>
			</uni-list>
		</uni-card>
		
		<!-- 字体大小调节 - 使用uni-ui的按钮组组件 -->
		<view class="font-controls">
			<uni-button-group>
				<uni-button 
					@click="decreaseFontSize" 
					size="mini"
					type="default"
					:disabled="fontSize <= 0.8">
					<uni-icons type="minus" size="16"></uni-icons>
				</uni-button>
				<uni-button 
					@click="increaseFontSize" 
					size="mini"
					type="default"
					:disabled="fontSize >= 1.5">
					<uni-icons type="plus" size="16"></uni-icons>
				</uni-button>
			</uni-button-group>
		</view>
		
		<!-- 服务预约表单 -->
		<uni-card title="服务预约" v-if="showAppointment">
			<uni-forms :model="appointmentForm">
				<uni-forms-item label="服务类型">
					<uni-data-select 
						v-model="appointmentForm.serviceType"
						:localdata="serviceTypes"
						placeholder="请选择服务类型">
					</uni-data-select>
				</uni-forms-item>
				<uni-forms-item label="日期">
					<uni-datetime-picker 
						type="date" 
						v-model="appointmentForm.date"
						placeholder="请选择日期">
					</uni-datetime-picker>
				</uni-forms-item>
				<uni-forms-item label="时间">
					<uni-datetime-picker 
						type="time" 
						v-model="appointmentForm.time"
						placeholder="请选择时间">
					</uni-datetime-picker>
				</uni-forms-item>
				<uni-forms-item label="备注">
					<uni-easyinput 
						type="textarea" 
						v-model="appointmentForm.notes"
						placeholder="请输入特殊需求">
					</uni-easyinput>
				</uni-forms-item>
				<button 
					type="primary" 
					@click="submitAppointment"
					style="margin-top: 20px;">
					提交预约
				</button>
			</uni-forms>
		</uni-card>
		
		<!-- 联系护工列表 -->
		<uni-card title="可联系护工" v-if="showCaregivers">
			<uni-list>
				<uni-list-item 
					v-for="(item, index) in caregivers" 
					:key="index"
					:title="item.name" 
					:note="`${item.service}`"
					:thumb="item.avatar"
					clickable
					@click="contactCaregiver(item.phone)">
					<template v-slot:footer>
						<view class="caregiver-phone">
							<uni-icons type="phone" size="20" color="#007AFF"></uni-icons>
							<text>{{item.phone}}</text>
						</view>
					</template>
				</uni-list-item>
			</uni-list>
		</uni-card>
	</view>
</template>

<script>
	export default {
		data() {
			return {
				fabPattern: {
					color: '#fff',
					backgroundColor: '#FF5252',
					selectedColor: '#FF5252',
					buttonColor: '#FF5252',
					iconColor: '#fff'
				},
				valueStyle: {
					color: '#2c3e50',
					fontSize: '24px',
					fontWeight: 'bold'
				},
				titleStyle: {
					color: '#7f8c8d',
					fontSize: '14px'
				},
				fabContent: [
					{
						iconPath: '/static/emergency.png',
						selectedIconPath: '/static/emergency-active.png',
						text: '紧急呼叫',
						active: false
					}
				],
				backgroundImage: 'https://ts4.tc.mm.bing.net/th/id/OIP-C.pWvd3dJePVoxO_PjtgA9rgHaLH?rs=1&pid=ImgDetMain&o=7&rm=3',
				showMedication: false,
				showAppointment: false,
				medicationCount: 3,
				appointmentForm: {
					serviceType: '体检',
					date: '',
					time: '',
					notes: ''
				},
				serviceTypes: ['体检', '理疗', '上门护理', '康复训练'],
				caregivers: [
					{
						name: '张护士',
						phone: '13800138001',
						service: '日常护理',
						avatar: '/static/nurse1.png'
					},
					{
						name: '李护工',
						phone: '13800138002',
						service: '康复训练',
						avatar: '/static/nurse2.png'
					},
					{
						name: '王医生',
						phone: '13800138003',
						service: '医疗咨询',
						avatar: '/static/doctor.png'
					}
				],
				fontSize: 1,
				showChart: false,
				chartData: {
					labels: ['周一', '周二', '周三', '周四', '周五', '周六', '周日'],
					datasets: [
						{
							label: '心率',
							data: [72, 75, 78, 76, 80, 82, 78],
							borderColor: '#FF5252',
							tension: 0.1
						},
						{
							label: '收缩压',
							data: [120, 118, 122, 120, 125, 123, 120],
							borderColor: '#4CAF50',
							tension: 0.1
						}
					]
				},
				medications: [
					{
						name: '降压药',
						time: '08:00 早餐后',
						dosage: '1片',
						status: '待服用',
						thumb: '/static/pill.png'
					},
					{
						name: '维生素',
						time: '12:00 午餐后',
						dosage: '2粒',
						status: '待服用',
						thumb: '/static/vitamin.png'
					},
					{
						name: '降糖药',
						time: '19:00 晚餐前',
						dosage: '1片',
						status: '待服用',
						thumb: '/static/pill.png'
					}
				]
			}
		},
		methods: {
			handleEmergency() {
				uni.makePhoneCall({
					phoneNumber: '120'
				})
			},
			change(e) {
				if (e.index === 0) {
					this.showMedication = !this.showMedication
				}
			},
			takeMedication(index) {
				this.medications[index].status = '已服用'
				this.medicationCount--
				uni.showToast({
					title: '用药记录已更新',
					icon: 'success'
				})
			},
			change(e) {
				if (e.index === 0) {
					this.showMedication = !this.showMedication
					this.showAppointment = false
				} else if (e.index === 1) {
					this.showAppointment = !this.showAppointment
					this.showMedication = false
				}
			},
			submitAppointment() {
				uni.showModal({
					title: '预约成功',
					content: `您已成功预约${this.appointmentForm.serviceType}服务，时间：${this.appointmentForm.date} ${this.appointmentForm.time}`,
					showCancel: false,
					success: () => {
						this.showAppointment = false
						this.appointmentForm = {
							serviceType: '体检',
							date: '',
							time: '',
							notes: ''
						}
					}
				})
			},
			contactCaregiver(phone) {
				uni.makePhoneCall({
					phoneNumber: phone
				})
			},
			increaseFontSize() {
				if (this.fontSize < 1.5) {
					this.fontSize += 0.1
				}
			},
			decreaseFontSize() {
				if (this.fontSize > 0.8) {
					this.fontSize -= 0.1
				}
			},
			change(e) {
				if (e.index === 0) {
					this.showMedication = !this.showMedication
					this.showAppointment = false
					this.showCaregivers = false
					this.showChart = false
				} else if (e.index === 1) {
					this.showAppointment = !this.showAppointment
					this.showMedication = false
					this.showCaregivers = false
					this.showChart = false
				} else if (e.index === 2) {
					this.showCaregivers = !this.showCaregivers
					this.showMedication = false
					this.showAppointment = false
					this.showChart = false
				}
			},
			toggleChart() {
				uni.navigateTo({
					url: '/pages/health-chart/health-chart',
					success: () => console.log('跳转成功'),
					fail: (err) => console.error('跳转失败:', err),
					complete: () => console.log('跳转操作完成')
				})
			}
		},
		onReady() {
			// 初始化图表
			this.initChart()
		},
		methods: {
			initChart() {
				const ctx = uni.createCanvasContext('healthChart', this)
				new Chart(ctx, {
					type: 'line',
					data: this.chartData,
					options: {
						responsive: true,
						scales: {
							y: {
								beginAtZero: false
							}
						},
						plugins: {
							legend: {
								labels: {
									font: {
										size: 14
									}
								}
							}
						}
					}
				})
			}
		}
	}
</script>

<style>
	.container {
		padding: 24px;
		padding-top: 84px; /* 为自定义导航栏留出空间 */
		font-size: 16px;
		background: url('https://ts4.tc.mm.bing.net/th/id/OIP-C.pWvd3dJePVoxO_PjtgA9rgHaLH?rs=1&pid=ImgDetMain&o=7&rm=3') no-repeat center center;
		background-size: cover;
		background-attachment: fixed;
		min-height: 100vh;
		position: relative;
	}
	.container::before {
		content: '';
		position: absolute;
		top: 0;
		left: 0;
		right: 0;
		bottom: 0;
		background: rgba(255, 255, 255, 0.7);
		z-index: 0;
	}
	
	.custom-navbar {
		position: fixed;
		top: 0;
		left: 0;
		right: 0;
		height: 64px;
		background: linear-gradient(135deg, #3498db, #2980b9);
		color: #fff;
		display: flex;
		align-items: center;
		padding: 0 20px;
		z-index: 1000;
		box-shadow: 0 2px 10px rgba(0,0,0,0.1);
	}
	
	.navbar-left {
		margin-right: 15px;
	}
	
	.user-icon {
		width: 36px;
		height: 36px;
		border-radius: 50%;
		border: 2px solid rgba(255,255,255,0.3);
	}
	
	.navbar-title {
		font-size: 20px;
		font-weight: 600;
		flex: 1;
		text-align: center;
		letter-spacing: 0.5px;
		text-shadow: 0 1px 2px rgba(0,0,0,0.1);
	}
	.header {
		margin-bottom: 24px;
		position: relative;
		z-index: 1;
		text-align: center;
		padding: 16px 0;
	}
	.title {
		font-size: 28px;
		font-weight: 600;
		display: block;
		color: #2c3e50;
		letter-spacing: 0.5px;
		margin-bottom: 8px;
	}
	.subtitle {
		font-size: 18px;
		color: #7f8c8d;
		display: block;
		line-height: 1.5;
	}
	.health-data {
		display: flex;
		flex-direction: column;
		gap: 15px;
		position: relative;
		z-index: 1;
	}
	.data-item {
		display: flex;
		justify-content: space-between;
		font-size: 18px;
		background: rgba(255, 255, 255, 0.7);
		padding: 12px 15px;
		border-radius: 10px;
		box-shadow: 0 2px 8px rgba(0,0,0,0.1);
	}
	.grid-item {
		display: flex;
		flex-direction: column;
		align-items: center;
		justify-content: center;
		gap: 12px;
		font-size: 18px;
		padding: 20px 10px;
		height: 100%;
		background: rgba(255, 255, 255, 0.85);
		border-radius: 12px;
		transition: all 0.3s ease;
		position: relative;
		box-shadow: 0 2px 8px rgba(0,0,0,0.05);
	}
	
	.grid-item:hover {
		background: rgba(255, 255, 255, 0.95);
		transform: translateY(-3px);
		box-shadow: 0 4px 12px rgba(0,0,0,0.1);
		padding: 5px !important;
	}
	.uni-card {
		margin-bottom: 24px;
		border-radius: 16px !important;
		overflow: hidden;
		box-shadow: 0 4px 16px rgba(0,0,0,0.08);
		border: none !important;
		background: rgba(255, 255, 255, 0.95) !important;
		position: relative;
		z-index: 1;
		transition: transform 0.3s ease, box-shadow 0.3s ease;
	}
	.uni-card:hover {
		transform: translateY(-2px);
		box-shadow: 0 6px 20px rgba(0,0,0,0.12);
	}
	.uni-forms-item__label {
		font-size: 18px !important;
		color: #2c3e50 !important;
	}
	.uni-easyinput__content {
		font-size: 18px !important;
	}
	button {
		font-size: 18px !important;
		padding: 10px 0 !important;
		border-radius: 8px !important;
		transition: all 0.3s ease !important;
	}
	button[type="primary"] {
		background: linear-gradient(135deg, #3498db, #2980b9) !important;
		border: none !important;
	}
	button[type="default"] {
		background: rgba(255, 255, 255, 0.9) !important;
		border: 1px solid #eee !important;
	}
	.font-controls {
		display: flex;
		justify-content: flex-end;
		margin-bottom: 10px;
		gap: 10px;
		position: relative;
		z-index: 1;
	}
	.caregiver-phone {
		display: flex;
		align-items: center;
		gap: 5px;
		color: #3498db;
	}
	.container {
		font-size: calc(16px * v-bind('fontSize'));
	}
	.title {
		font-size: calc(28px * v-bind('fontSize'));
	}
	.subtitle {
		font-size: calc(18px * v-bind('fontSize'));
	}
	.data-item {
		font-size: calc(18px * v-bind('fontSize'));
	}
	.grid-item {
		font-size: calc(18px * v-bind('fontSize'));
	}
	.uni-forms-item__label {
		font-size: calc(18px * v-bind('fontSize')) !important;
	}
	.uni-easyinput__content {
		font-size: calc(18px * v-bind('fontSize')) !important;
	}
	button {
		font-size: calc(18px * v-bind('fontSize')) !important;
	}
	.uni-badge {
		transform: translate(10px, -10px) !important;
	}
</style>
